
const LoginPage = () => {


  return (
    <div className="w-[100%] h-screen flex flex-col justify-center items-center">
    
    </div>
  );
};

export default LoginPage;