type TForm = {
    label: string,
    register: any,
    errors: any,
    id: string,
    validate: any
    type: string,
    placeholder: string,
    style: string,
    containerClassName: string,
    inputClassName: string,
}