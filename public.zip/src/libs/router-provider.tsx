import { RouterProvider as RouterProviderLib } from "react-router-dom";

export const RouterProvider = ({ router }) => {
  return <RouterProviderLib router={router}></RouterProviderLib>;
};
