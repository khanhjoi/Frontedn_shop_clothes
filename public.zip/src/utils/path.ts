const path = {
    HOME: "/",
    LOGIN: "/login",
}

export default path