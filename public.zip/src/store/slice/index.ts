import userReducer from './user';

export default {
    user: userReducer
}